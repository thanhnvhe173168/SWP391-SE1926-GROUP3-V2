package controller.Feedback;

import dao.FeedbackDAO;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.File;
import model.Feedback;

@WebServlet(name="GiveFeedback", urlPatterns={"/giveFeedback"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class GiveFeedback extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet GiveFeedback</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet GiveFeedback at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        int userID = Integer.parseInt(request.getParameter("userID"));
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        int rating = Integer.parseInt(request.getParameter("rating"));
        int sellerRating = Integer.parseInt(request.getParameter("sellerRating"));
        int shippingRating = Integer.parseInt(request.getParameter("shippingRating"));

        int statusID = 28;

        
        Part filePart = request.getPart("productImage");

        String fileName = extractFileName(filePart); 
        String uploadPath = getServletContext().getRealPath("/upload/feedback");

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // Tránh overwrite file trùng tên
        File file = new File(uploadDir, fileName);
        int count = 0;
        String baseName = fileName;
        while (file.exists()) {
            count++;
            fileName = count + "_" + baseName;
            file = new File(uploadDir, fileName);
        }

        filePart.write(file.getAbsolutePath());

        String imageURL = "upload/feedback/" + fileName;

        Feedback fb = new Feedback();
        fb.setUserID(userID);
        fb.setTitle(title);
        fb.setContent(content);
        fb.setRating(rating);
        fb.setSellerRating(sellerRating);
        fb.setShippingRating(shippingRating);
        fb.setImageURL(imageURL);
        fb.setStatusID(statusID);

        FeedbackDAO dao = new FeedbackDAO();
        boolean giveF = dao.addFeedback(fb);
        if (giveF) {
            request.setAttribute("mess", "Cảm ơn bạn đã gửi phản hồi");
            request.getRequestDispatcher("user/feedbackSuccess.jsp").forward(request, response);
        } else {
            request.setAttribute("mess", "Có lỗi xảy ra! Vui lòng thử lại");
            request.getRequestDispatcher("user/GiveFeedback.jsp").forward(request, response);
        }
    }

    
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                String fileName = s.substring(s.indexOf("=") + 2, s.length() - 1);
                return fileName;
            }
        }
        return "";
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
