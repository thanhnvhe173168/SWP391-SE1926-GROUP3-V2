/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.ConnectDB;
import model.Feedback;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author linhd
 */
public class FeedbackDAO extends ConnectDB {

    public List<Feedback> getAllFeedbacks() {
        List<Feedback> list = new ArrayList<>();
        String sql = "SELECT FeedbackID, UserID, Title, Content, CreatedAt, UpdatedAt, StatusID FROM Feedback";
        try {
            PreparedStatement ps = connect.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Feedback fb = new Feedback();
                fb.setFeedbackID(rs.getInt("FeedbackID"));
                fb.setUserID(rs.getInt("UserID"));
                fb.setTitle(rs.getString("Title"));
                fb.setContent(rs.getString("Content"));
                fb.setCreatedAt(rs.getTimestamp("CreatedAt"));
                fb.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                fb.setStatusID(rs.getInt("StatusID"));

                list.add(fb);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    //Customer Feedback List
    public List<Feedback> getFeedbackByUser(int userID) {
        List<Feedback> list = new ArrayList<>();
        String sql = "SELECT * FROM Feedback WHERE UserID = ?";
        try {
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, userID);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Feedback feedback = new Feedback();
                feedback.setFeedbackID(rs.getInt("FeedbackID"));
                feedback.setUserID(rs.getInt("UserID"));
                feedback.setTitle(rs.getString("Title"));
                feedback.setContent(rs.getString("Content"));
                feedback.setCreatedAt(rs.getTimestamp("CreatedAt"));
                feedback.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                feedback.setStatusID(rs.getInt("StatusID"));
                feedback.setImageURL(rs.getString("ImageURL"));
                list.add(feedback);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

//Give feedback    
    public boolean addFeedback(Feedback feedback) {
        String sql = "INSERT INTO Feedback (UserID, Title, Content, Rating, SellerRating, ShippingRating, ImageURL, StatusID) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, feedback.getUserID());
            ps.setString(2, feedback.getTitle());
            ps.setString(3, feedback.getContent());
            ps.setInt(4, feedback.getRating());
            ps.setInt(5, feedback.getSellerRating());
            ps.setInt(6, feedback.getShippingRating());
            ps.setString(7, feedback.getImageURL());
            ps.setInt(8, feedback.getStatusID());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public void deleteFeedback(int feedbackID) {
        String sql = "Delete from Feedback where FeedbackID=?";
        try {
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, feedbackID);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//updateFeedback
    public Feedback getFeedbackByID(int id) {
        Feedback fb = null;
        String sql = "Select * from Feedback where FeedbackID=?";
        try {
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                fb = new Feedback();
                fb.setFeedbackID(rs.getInt("FeedbackID"));
                fb.setUserID(rs.getInt("UserID"));
                fb.setTitle(rs.getString("Title"));
                fb.setContent(rs.getString("Content"));
                fb.setRating(rs.getInt("Rating"));
                fb.setSellerRating(rs.getInt("SellerRating"));
                fb.setShippingRating(rs.getInt("ShippingRating"));
                fb.setImageURL(rs.getString("ImageURL"));
                fb.setStatusID(rs.getInt("StatusID"));
                fb.setCreatedAt(rs.getTimestamp("CreatedAt"));
                fb.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                return fb;

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return fb;
    }

    public int updateFeedback(int feedbackID, String title, String content, int rating, int sellerRating, int shippingRating) {
        int n = 0;
        String sql = "Update Feedback set Title = ?, Content =?,Rating =?, SellerRating=?, ShippingRating=?, UpdatedAt=GETDATE() WHERE FeedbackID=?";
        try {
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setString(1,title);
            ps.setString(2, content);
            ps.setInt(3, rating);
            ps.setInt(4, sellerRating);
            ps.setInt(5,shippingRating);
            ps.setInt(6, feedbackID);
            n = ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return n;
    }
}
